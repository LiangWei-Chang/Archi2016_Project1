/***************************************************

	File: Register.h

	Author: PinYo

***************************************************/

#ifndef Register_h
#define Register_h

#include <string>
using namespace std;

class Register{

public:
	int value;
	string Hex();
};

#endif